package co.edu.poli.actividad4.servicios;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ImplementarOperacion {

    /**
     * Default constructor
     */
    public ImplementarOperacion() {
    }

}