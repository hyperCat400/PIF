package co.edu.poli.actividad2.modelo;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Ciudad {

    /**
     * Default constructor
     */
    public Ciudad() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private ClinicaVeterinaria[ ] listaClinicas;

    /**
     * 
     */
    public void gestionarTurnos() {
        // TODO implement here
    }

    /**
     * 
     */
    public void notificarDisponibilidad() {
        // TODO implement here
    }

}